<?php
    require_once('../config.php');
	
	include_once("../code/template/header.php");
	
	?>
<!DOCTYPE html>
<style>
.h3, h3 {
    font-size: 24px!important;
    text-shadow: 5px 4px 8px grey;
}
</style>
<html lang="en">
<section class="content">
	<div class="row">
		<div class="col-xs-12">
			<div class="box box-primary">
				<div class="box-header">
					<h3 class="box-title">Support</h3>
    <head>
<link rel="icon" href="../favicon.png" type="image/ico" sizes="32x32">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact Us</title>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
    </head>
    <body >
        <div class="container">
            <div class="form-container">
                <h1>
                    Contact Us
                </h1>
                <form method="post" id="reused_form" >
                    <label for="name">Your Name:</label>
                    <input id="name" type="text" name="Name" required maxlength="50">
                    <label for="email">Email Address:</label>
                    <input id="email" type="email" name="Email" required maxlength="50">
                    <label for="message">Message:</label>
                    <textarea id="message" name="Message" rows="10" maxlength="6000" required></textarea>
                    <button class="button-primary" type="submit" >Send Now</button>
                </form>
                <div id="success_message" style="display:none">
                    <h3>The message was sent successfully!</h3> 
                    <p> We will get back to you soon. </p>
                </div>
                <div id="error_message" style="width:100%; height:100%; display:none; "> <h3>Error</h3> Sorry there was an error sending your form. </div>
            </div>
        </div>
		</div>
		</div>
		</div>
		</div>
		</section>
    </body>
</html>
<?php
include_once("../code/template/footer.php");
?>
